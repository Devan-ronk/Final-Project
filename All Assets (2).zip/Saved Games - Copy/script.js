let opacity = 1;

var click = new Audio('click.mp3');

var music = new Audio('music.mp3');

var error = new Audio('locked.mp3');

var swimProgress = 0;

music.play();
music.loop = true;

let currentVolume = 100;

let x = 1;

let levelNum = 1;

let onedone = false;
let twodone = false;
let threedone = false;
let fourdone = false;
let fivedone = false;

function duction() {
    const intro = document.getElementById('intro');
    const game = document.getElementById('game');
}

function introduction() {

    backtomenu();
    opacity -= 0.01; 
    intro.style.opacity = opacity;
    if (opacity <= 0) {
        intro.style.display = 'none';
        game.style.display = 'block';
    } else {
        requestAnimationFrame(introduction);
    }
}

setTimeout(() => {
  requestAnimationFrame(introduction);
}, 1000);

function clickPlay() {
    click.pause();
    click.currentTime = 0;
    click.play();
}

function backtomenu() {
    clickPlay();
    document.getElementById('game').innerHTML ='<img src="title.png" width="700px"><br>'
    document.getElementById('game').innerHTML += '<button id="play" onClick="gamestart()"><img src="play.png" width="250px"></button>'
    document.getElementById('game').innerHTML += '<button id="options" onClick="options()"><img src="options.png" width="250px"></button>'
}

function gamestart() {
    clickPlay();
    back();
    document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
    document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
    document.getElementById('game').innerHTML += '<button id="one" onClick="one()"><img src="one.png" width="500px"></button>'
    document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
    document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="ethan.png" width="200px">'
    document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. G-than Elong</h1>'
    document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
}

function back() {
    document.getElementById('game').innerHTML = '<button id="back" onclick="backtomenu()"><img src="back.png" width="100px"></button>';

}

function options() {
    clickPlay();
    back();
    document.getElementById('game').innerHTML += '<img src="optionstitle.gif" width="400px"><br>'
    document.getElementById('game').innerHTML += '<button id="fullscreen" onClick="fullscreen()"><img src="fullscreen.png" width="100px"></button>';
    document.getElementById('game').innerHTML += '<button id="credits" onClick="credits()"><img src="credits.png" width="250px"></button><br><br>';
    document.getElementById('game').innerHTML += '<img src="volumetitle.png" width="200px"><br><br>';
    document.getElementById('game').innerHTML += `<input type="range" min="0" max="100" value="${currentVolume}" id="volume" class="slider">`
    volume_slide();
    let x = 1;
}

function volume_slide() {
    let volume = document.getElementById('volume');
    volume.addEventListener('input', function(e) {
        currentVolume = volume.value;
        click.volume = volume.value / 100;
        music.volume = volume.value / 100;
    });
}

function fullscreen() {
    clickPlay();
    document.documentElement.requestFullscreen();
}

function credits() {
    clickPlay();
    back();
        document.getElementById('game').innerHTML += '<br><h1>Credits</h1><br><h2>Game: Benjamin F. Wu and Moebius</h2><br><h2>Teacher: Dr. Williams</h2><br><h2>Music: Royalty Free</h2>'
}

function forward() {
    clickPlay();
    if  (levelNum == 1) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (onedone == true) {
        document.getElementById('game').innerHTML += '<button id="two" onClick="two()"><img src="two.png" width="500px"></button>'
        } else {
        document.getElementById('game').innerHTML += '<button id="twolocked" onClick="error.play()"><img src="twolocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="dorsey.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Morsey Ditchell</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 2;
    } else if (levelNum == 2) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (twodone == true) {
            document.getElementById('game').innerHTML += '<button id="three" onClick="three()"><img src="three.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="threelocked" onClick="error.play()"><img src="threelocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="david.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. David Chin</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 3;
    } else if (levelNum == 3) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (threedone == true) {
            document.getElementById('game').innerHTML += '<button id="four" onClick="four()"><img src="four.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="fourlocked" onClick="error.play()"><img src="fourlocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="matthew.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Trash Baby</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 4;
    } else if (levelNum == 4) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (fourdone == true) {
            document.getElementById('game').innerHTML += '<button id="five" onClick="five()"><img src="five.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="fivelocked" onClick="error.play()"><img src="fivelocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="ilyas.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Elias Ilmanowie</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 5;
    }else if (levelNum == 5) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (fivedone == true) {
            document.getElementById('game').innerHTML += '<button id="six onClick="six()"><img src="six.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="sixlocked" onClick="error.play()"><img src="sixlocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="shark.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. A Shark</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 6;
    } else if (levelNum == 6) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<button id="one" onClick="one()"><img src="one.png" width="500px"></button>'
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="ethan.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. G-than Elong</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 1;

} else{
}
}

function backward() {
    clickPlay();
    if  (levelNum == 1) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (fivedone == true) {
            document.getElementById('game').innerHTML += '<button id="six onClick="six()"><img src="six.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="sixlocked" onClick="error.play()"><img src="sixlocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="shark.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. A Shark</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 6;
    } else if (levelNum == 2) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<button id="one" onClick="one()"><img src="one.png" width="500px"></button>'
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="ethan.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. G-than Elong</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 1;
    } else if (levelNum == 3) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (onedone == true) {
            document.getElementById('game').innerHTML += '<button id="two" onClick="two()"><img src="two.png" width="500px"></button>'
            } else {
            document.getElementById('game').innerHTML += '<button id="twolocked" onClick="error.play()"><img src="twolocked.png" width="500px"></button>'
            }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
        document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="dorsey.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Morsey Ditchell</h1>'
         document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 2;
    } else if (levelNum == 4) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (twodone == true) {
            document.getElementById('game').innerHTML += '<button id="three" onClick="three()"><img src="three.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="threelocked" onClick="error.play()"><img src="threelocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
         document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="david.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. David Chin</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 3;
    }else if (levelNum == 5) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (threedone == true) {
            document.getElementById('game').innerHTML += '<button id="four" onClick="four()"><img src="four.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="fourlocked" onClick="error.play()"><img src="fourlocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
         document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="matthew.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Trash Baby</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 4;
    } else if (levelNum == 6) {
        back();
        document.getElementById('game').innerHTML += '<img src="gamestart.png" width="400px"><br>'
        document.getElementById('game').innerHTML += '<button id="backward" onClick="backward()"><img src="backward.png" width="60px"></button>'
        if (fourdone == true) {
            document.getElementById('game').innerHTML += '<button id="five" onClick="five()"><img src="five.png" width="500px"></button>'
        } else {
            document.getElementById('game').innerHTML += '<button id="fivelocked" onClick="error.play()"><img src="fivelocked.png" width="500px"></button>'
        }
        document.getElementById('game').innerHTML += '<button id="forward" onClick="forward()"><img src="forward.png" width="60px"></button>'
          document.getElementById('game').innerHTML += '<br><img src="ben.png" width="200px"><img src="vs.png" width="200px"><img src="ilyas.png" width="200px">'
        document.getElementById('game').innerHTML += '<br><h1>Wen Bu vs. Elias Ilmanowie</h1>'
        document.getElementById('game').innerHTML += '<br><br><button id="shop" onClick="shop()"><img src="shop.png" width="100px"></button>'
        levelNum = 5;

}
}
function shop() {
    clickPlay();
    back();
    document.getElementById('game').innerHTML += '<img src="shoptitle.png" width="400px"><br>'
}

function one() {
    clickPlay();
    document.getElementById('game').style.backgroundImage = 'url("")';
    document.getElementById('game').innerHTML += 
    document.getElementById('game').innerHTML += 
    document.getElementById('game').innerHTML += 
    countdown();
}

function two() {

}

function three() {

}

function four() {  

}

function five() {  

}

function six() {
    
}


function countdown() {
    document.getElementById('game').innerHTML += '<img src="" width="400px"><br>'
    setTimeout(() => {
        document.getElementById('game').innerHTML = '<img src="" width="400px"><br>'
        
    }, 3000);
}

function swimPlay() {
    swimProgress += 1;
    if (swimProgress = 100) {
        swimProgress = 0;
    } else {
    }
}


duction();
